package roseindia.web.common;
import java.util.*;

public class AboutUs {
	
	
    private String aboutustext;

	public String getAboutustext() {
		return aboutustext;
	}

	public void setAboutustext(String aboutustext) {
		this.aboutustext = aboutustext;
	}

	
}

  
	
	
	

