package roseindia.web.common;
import java.util.*;
/*
 * bean class to set or get shipping delivery text
 */
public class ShippingDelivery {
	
	//identifier field
    private String shipdeltext;
    /*
     * setter getter methods
     * */
	public String getShipdeltext() {
		return shipdeltext;
	}

	public void setShipdeltext(String shipdeltext) {
		this.shipdeltext = shipdeltext;
	}

	
	
}

  
	
	
	

