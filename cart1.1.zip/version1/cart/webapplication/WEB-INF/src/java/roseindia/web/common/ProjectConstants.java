/*
 * Created on Oct 16, 2006
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package roseindia.web.common;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class ProjectConstants {
	public static String MAIL_BEAN="mailbean";
	
	public static String FROM_MAIL="deepak@localhost";
}
