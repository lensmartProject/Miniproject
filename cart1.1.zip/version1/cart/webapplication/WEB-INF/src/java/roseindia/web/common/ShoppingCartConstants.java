package roseindia.web.common;

public class ShoppingCartConstants {

	//Shopping cart Dao bean
	public static final String DAO_BEAN="ShoppingCartDao";
	
	
	
}
